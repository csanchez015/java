package com.christiansanchez.hoppersreceipt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoppersreceiptApplicationTests {

	@Test
	void contextLoads() {
	}

}
