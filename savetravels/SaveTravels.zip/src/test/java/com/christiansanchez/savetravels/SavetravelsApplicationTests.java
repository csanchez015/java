package com.christiansanchez.savetravels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavetravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
