package com.christiansanchez.loginandregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginandregistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginandregistrationApplication.class, args);
	}

}
